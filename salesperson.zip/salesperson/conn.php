<?php
$link = mysqli_connect("localhost", "littlefi_lavems", "2wsxzaQ1!6ytrew21!", "littlefi_lavems");

if ($link === false){
die("ERROR: Could not connect. " . mysqli_connect_error());
}
?>